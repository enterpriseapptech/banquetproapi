export class CreateCateringDto {}
