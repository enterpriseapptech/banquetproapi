export class Catering {}
