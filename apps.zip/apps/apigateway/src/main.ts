import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true, // Remove unknown fields
    // forbidNonWhitelisted: true, // Throw an error for extra fields
    transform: true, // Transform payload into DTO instance
  }));

  // Swagger Configuration
  const config = new DocumentBuilder()
    .setTitle('My Microservice API')
    .setDescription('API documentation for my NestJS microservice')
    .setVersion('1.0')
    .addTag('microservice')
    .build();
  
  
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);

  await app.listen(8000);
}

bootstrap();
