export class Booking {}
